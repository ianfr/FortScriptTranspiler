include(CheckSourceCompiles)

# --- not all platforms have ieee_arithmetic e.g. aarch64 GCC
check_source_compiles(Fortran
"program a
use, intrinsic :: ieee_arithmetic, only : ieee_quiet_nan, ieee_value
real :: NaN
NaN = ieee_value(0., ieee_quiet_nan)
end program"
HAVE_IEEE_ARITH
)

set(h5fortran_fflags)

# --- Fortran compile flags
if(CMAKE_Fortran_COMPILER_ID MATCHES "^Intel")

list(APPEND h5fortran_fflags
"$<$<AND:$<COMPILE_LANGUAGE:Fortran>,$<CONFIG:Debug,RelWithDebInfo>>:-warn>"
"$<$<AND:$<COMPILE_LANGUAGE:Fortran>,$<CONFIG:Debug>>:-traceback;-check;-debug>"
)

if(WIN32)
  list(APPEND h5fortran_fflags "$<$<AND:$<COMPILE_LANGUAGE:Fortran>,$<CONFIG:Debug>>:/Od>")
else()
  list(APPEND h5fortran_fflags "$<$<AND:$<COMPILE_LANGUAGE:Fortran>,$<CONFIG:Debug>>:-O0>")
endif()

elseif(CMAKE_Fortran_COMPILER_ID STREQUAL "GNU")

list(APPEND h5fortran_fflags
"$<$<AND:$<COMPILE_LANGUAGE:Fortran>,$<CONFIG:Debug,RelWithDebInfo>>:-Wall>"
"$<$<COMPILE_LANGUAGE:Fortran>:-fimplicit-none;-Wno-maybe-uninitialized>"
"$<$<AND:$<COMPILE_LANGUAGE:Fortran>,$<CONFIG:Debug>>:-Wextra;-fcheck=all;-Werror=array-bounds>"
"$<$<AND:$<COMPILE_LANGUAGE:Fortran>,$<CONFIG:Release>>:-fno-backtrace>"
)

endif()

# --- code coverage
if(h5fortran_coverage)
  include(${CMAKE_CURRENT_LIST_DIR}/Modules/CodeCoverage.cmake)
  append_coverage_compiler_flags()
  set(COVERAGE_EXCLUDES ${h5fortran_SOURCE_DIR}/test)
endif()

# --- clang-tidy
if(h5fortran_tidy AND h5fortran_IS_TOP_LEVEL)
  find_program(CLANG_TIDY_EXE NAMES "clang-tidy" REQUIRED)
  set(CMAKE_C_CLANG_TIDY ${CLANG_TIDY_EXE})
  set(CMAKE_CXX_CLANG_TIDY ${CLANG_TIDY_EXE})
endif()
